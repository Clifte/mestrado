function res = ajustaContraste(image, c)
    res = image*c;
end
