function res = ajustaBrilho(image, b)
    res = image + b;
end

