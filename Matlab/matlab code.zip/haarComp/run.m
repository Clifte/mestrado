close all;
haar_compression('tom.jpg',100,4);

