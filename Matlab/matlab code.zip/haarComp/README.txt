Image compression using Haar wavelet
By Arash Fattahi, Omid Aladini {r_ash,omid}@cs.sharif.edu

To compress an image use this command in MATLAB:

haar_compression(FILE_NAME,COMP_LEVEL,MOSAIC_SIZE)

example:

haar_compression('dancer.jpg',50,3) //Haar mosaic size will be 2^3

